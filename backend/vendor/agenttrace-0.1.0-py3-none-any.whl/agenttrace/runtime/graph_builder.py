from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Iterable


def _span_node(span: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": span["span_id"],
        "span_id": span["span_id"],
        "parent_span_id": span.get("parent_span_id"),
        "logical_node_key": span["logical_node_key"],
        "name": span["name"],
        "kind": span["kind"],
        "status": span["status"],
        "start_sequence": span["start_sequence"],
        "started_at": span["started_at"],
        "ended_at": span.get("ended_at"),
        "duration_ns": span.get("duration_ns") or 0,
        "log_count": span.get("log_count", 0),
        "error_type": span.get("error_type"),
        "attributes": span.get("attributes", {}),
    }


def build_expanded(turn: dict[str, Any], spans: list[dict[str, Any]], predecessors: list[dict[str, Any]]) -> dict[str, Any]:
    ordered = sorted(spans, key=lambda item: (item["start_sequence"], item["span_id"]))
    nodes = [_span_node(span) for span in ordered]
    edges: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for span in ordered:
        if span.get("parent_span_id"):
            edge = (span["parent_span_id"], span["span_id"], "parent")
            if edge not in seen:
                edges.append({"source": edge[0], "target": edge[1], "relation": edge[2], "confidence": "authoritative"})
                seen.add(edge)
    for predecessor in predecessors:
        edge = (predecessor["predecessor_span_id"], predecessor["span_id"], predecessor["relation"])
        if edge not in seen:
            edges.append({
                "source": edge[0], "target": edge[1], "relation": edge[2],
                "confidence": predecessor["confidence"],
            })
            seen.add(edge)
    started = turn.get("started_at") or (ordered[0]["started_at"] if ordered else None)
    ended = turn.get("ended_at") or (ordered[-1].get("ended_at") if ordered else None)
    return {
        "projection": "expanded",
        "turn": turn,
        "nodes": nodes,
        "edges": edges,
        "timeline": {"started_at": started, "ended_at": ended, "duration_ns": turn.get("duration_ns") or 0},
    }


def build_aggregated(turn: dict[str, Any], spans: list[dict[str, Any]], predecessors: list[dict[str, Any]]) -> dict[str, Any]:
    ordered = sorted(spans, key=lambda item: (item["start_sequence"], item["span_id"]))
    by_id = {span["span_id"]: span for span in ordered}
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for span in ordered:
        groups[span["logical_node_key"]].append(span)
    nodes = []
    for key, instances in sorted(groups.items(), key=lambda item: min(row["start_sequence"] for row in item[1])):
        statuses = Counter(row["status"] for row in instances)
        first = instances[0]
        status = "error" if statuses["error"] else "incomplete" if statuses["incomplete"] else "cancelled" if statuses["cancelled"] else "ok"
        nodes.append({
            "id": key,
            "logical_node_key": key,
            "name": first["name"],
            "kind": first["kind"],
            "status": status,
            "call_count": len(instances),
            "total_duration_ns": sum(row.get("duration_ns") or 0 for row in instances),
            "span_ids": [row["span_id"] for row in instances],
            "first_sequence": min(row["start_sequence"] for row in instances),
            "history_only": False,
        })

    transitions: Counter[tuple[str, str, str]] = Counter()
    predecessor_targets: set[str] = set()
    for relation in predecessors:
        source = by_id.get(relation["predecessor_span_id"])
        target = by_id.get(relation["span_id"])
        if source and target and source["logical_node_key"] != target["logical_node_key"]:
            transitions[(source["logical_node_key"], target["logical_node_key"], relation["relation"])] += 1
            predecessor_targets.add(target["span_id"])
    for span in ordered:
        parent = by_id.get(span.get("parent_span_id"))
        if parent and span["span_id"] not in predecessor_targets and parent["logical_node_key"] != span["logical_node_key"]:
            transitions[(parent["logical_node_key"], span["logical_node_key"], "parent")] += 1
    edges = [
        {"id": f"{source}:{target}:{relation}", "source": source, "target": target, "relation": relation, "count": count, "history_only": False}
        for (source, target, relation), count in sorted(transitions.items())
    ]
    return {"projection": "aggregated", "turn": turn, "nodes": nodes, "edges": edges}


def merge_history(current: dict[str, Any], historical: Iterable[dict[str, Any]]) -> dict[str, Any]:
    result = {**current, "nodes": [dict(node) for node in current["nodes"]], "edges": [dict(edge) for edge in current["edges"]]}
    current_nodes = {node["logical_node_key"]: node for node in result["nodes"]}
    current_edges = {(edge["source"], edge["target"]): edge for edge in result["edges"]}
    history_node_counts: Counter[str] = Counter()
    history_edge_counts: Counter[tuple[str, str]] = Counter()
    history_templates: dict[str, dict[str, Any]] = {}
    for graph in historical:
        for node in graph["nodes"]:
            key = node["logical_node_key"]
            history_node_counts[key] += node.get("call_count", 1)
            history_templates[key] = node
        for edge in graph["edges"]:
            history_edge_counts[(edge["source"], edge["target"])] += edge.get("count", 1)
    for key, count in history_node_counts.items():
        if key in current_nodes:
            current_nodes[key]["history_call_count"] = count
        else:
            template = history_templates[key]
            result["nodes"].append({**template, "span_ids": [], "call_count": 0, "history_call_count": count, "history_only": True})
    for (source, target), count in history_edge_counts.items():
        if (source, target) in current_edges:
            current_edges[(source, target)]["history_count"] = count
        else:
            result["edges"].append({
                "id": f"history:{source}:{target}", "source": source, "target": target,
                "relation": "history", "count": 0, "history_count": count, "history_only": True,
            })
    result["history_comparison"] = True
    return result

