from __future__ import annotations

import logging
import secrets
import threading
import time
import traceback
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterator
from uuid import UUID

from agenttrace.config import Config
from agenttrace.context import SessionContext, SpanContext, TurnContext, session_var, span_var, turn_var
from agenttrace.models import SerializedValue, SpanEnd, SpanKind, SpanStart
from agenttrace.redaction import Redactor
from agenttrace.serialization import serialize, serialize_call
from agenttrace.storage.sqlite import SQLiteStorage

internal_logger = logging.getLogger("agenttrace.internal")
internal_logger.propagate = False


def uuid7() -> str:
    timestamp_ms = int(time.time() * 1000) & ((1 << 48) - 1)
    random_bits = secrets.randbits(74)
    value = (timestamp_ms << 80) | (0x7 << 76) | ((random_bits >> 62) << 64)
    value |= 0b10 << 62
    value |= random_bits & ((1 << 62) - 1)
    return str(UUID(int=value))


def trace_id() -> str:
    return secrets.token_hex(16)


def span_id() -> str:
    return secrets.token_hex(8)


class Lifecycle:
    def __init__(self, recorder: "Recorder", *, kind: SpanKind, name: str, logical_node_key: str,
                 input_value: SerializedValue | None, attributes: dict[str, Any] | None = None,
                 source: str = "decorator"):
        self.recorder = recorder
        self.kind = kind
        self.name = name
        self.logical_node_key = logical_node_key
        self.input_value = input_value
        self.attributes = dict(attributes or {})
        self.source = source
        self.id = span_id()
        self.parent = span_var.get()
        self.turn = turn_var.get()
        self.started_ns = time.perf_counter_ns()
        self.started_at = datetime.now(timezone.utc)
        self.finished = False
        self.disabled = self.turn is None
        if self.disabled:
            return
        self.start_sequence = self.turn.next_sequence()
        record = SpanStart(
            span_id=self.id,
            trace_id=self.turn.trace_id,
            turn_id=self.turn.id,
            session_id=self.turn.session_id,
            project_id=self.turn.project_id,
            parent_span_id=self.parent.id if self.parent else self.turn.root_span_id,
            logical_node_key=self.logical_node_key,
            name=self.name,
            kind=self.kind,
            start_sequence=self.start_sequence,
            started_at=self.started_at,
            input_value=input_value,
            attributes={
                **self.attributes,
                "agenttrace.schema.version": "1.0",
                "agenttrace.session.id": self.turn.session_id,
                "agenttrace.turn.id": self.turn.id,
                "agenttrace.span.kind": kind,
                "agenttrace.logical_node.key": logical_node_key,
                "agenttrace.sequence": self.start_sequence,
                "agenttrace.capture.source": source,
            },
            resource={"service.name": recorder.config.project},
            instrumentation_scope={"name": "agenttrace", "version": "0.1.0"},
        )
        try:
            recorder.storage.start_span(record)
            parent_key = record.parent_span_id or self.turn.root_span_id
            previous = self.turn.last_completed_by_parent.get(parent_key)
            if previous and previous[1] <= self.started_ns:
                recorder.storage.add_predecessor(self.id, previous[0])
        except Exception as exc:
            self._storage_error(exc)

    def _storage_error(self, exc: Exception) -> None:
        if self.recorder.config.strict_mode:
            raise exc
        internal_logger.error("AgentTrace storage operation failed: %s", exc)

    @contextmanager
    def activate(self) -> Iterator[None]:
        if self.disabled:
            yield
            return
        token = span_var.set(SpanContext(self.id, self.parent.id if self.parent else self.turn.root_span_id,
                                         self.started_ns, self.name, self.logical_node_key))
        try:
            yield
        finally:
            span_var.reset(token)

    def finish(self, *, status: str = "ok", output: Any = None, capture_output: bool = True,
               error: BaseException | None = None, attributes: dict[str, Any] | None = None) -> None:
        if self.finished or self.disabled:
            self.finished = True
            return
        self.finished = True
        ended_ns = time.perf_counter_ns()
        ended_at = datetime.now(timezone.utc)
        output_value = self.recorder.capture(output) if capture_output else None
        error_type = error_message = error_stack = None
        if error is not None:
            error_type = f"{type(error).__module__}.{type(error).__qualname__}"
            error_message, _ = self.recorder.redactor.redact_text(str(error))
            stack = "".join(traceback.format_exception(type(error), error, error.__traceback__))
            error_stack, _ = self.recorder.redactor.redact_text(stack)
        try:
            self.recorder.storage.end_span(SpanEnd(
                span_id=self.id,
                status=status,  # type: ignore[arg-type]
                end_sequence=self.turn.next_sequence(),
                ended_at=ended_at,
                duration_ns=ended_ns - self.started_ns,
                output_value=output_value,
                error_type=error_type,
                error_message=error_message,
                error_stack=error_stack,
                attributes=attributes or {},
            ))
            parent_key = self.parent.id if self.parent else self.turn.root_span_id
            self.turn.last_completed_by_parent[parent_key] = (self.id, ended_ns)
        except Exception as exc:
            self._storage_error(exc)


class TurnLifecycle(Lifecycle):
    def __init__(self, recorder: "Recorder", *, name: str, logical_node_key: str, session_id: str,
                 input_value: SerializedValue | None, title: str, attributes: dict[str, Any] | None = None):
        self.recorder = recorder
        self.kind = "turn"
        self.name = name
        self.logical_node_key = logical_node_key
        self.input_value = input_value
        self.attributes = dict(attributes or {})
        self.source = "decorator"
        self.id = span_id()
        self.parent = None
        self.started_ns = time.perf_counter_ns()
        self.started_at = datetime.now(timezone.utc)
        self.finished = False
        self.disabled = False
        self.turn = TurnContext(
            id=uuid7(), session_id=session_id, trace_id=trace_id(), project_id=recorder.project_id,
            root_span_id=self.id,
        )
        self.start_sequence = self.turn.next_sequence()
        try:
            recorder.storage.begin_turn(
                project_id=recorder.project_id, session_id=session_id, turn_id=self.turn.id,
                trace_id=self.turn.trace_id, root_span_id=self.id, title=title,
                started_at=self.started_at, input_value=input_value,
            )
            recorder.storage.start_span(SpanStart(
                span_id=self.id,
                trace_id=self.turn.trace_id,
                turn_id=self.turn.id,
                session_id=session_id,
                project_id=recorder.project_id,
                parent_span_id=None,
                logical_node_key=logical_node_key,
                name=name,
                kind="turn",
                start_sequence=self.start_sequence,
                started_at=self.started_at,
                input_value=input_value,
                attributes={
                    **self.attributes,
                    "agenttrace.schema.version": "1.0",
                    "agenttrace.session.id": session_id,
                    "agenttrace.turn.id": self.turn.id,
                    "agenttrace.span.kind": "turn",
                    "agenttrace.logical_node.key": logical_node_key,
                    "agenttrace.sequence": self.start_sequence,
                    "agenttrace.capture.source": "decorator",
                },
                resource={"service.name": recorder.config.project},
                instrumentation_scope={"name": "agenttrace", "version": "0.1.0"},
            ))
        except Exception as exc:
            if recorder.config.strict_mode:
                raise
            internal_logger.error("AgentTrace failed to begin turn: %s", exc)
            self.disabled = True

    @contextmanager
    def activate(self) -> Iterator[None]:
        if self.disabled:
            yield
            return
        existing_session = session_var.get()
        session_token = session_var.set(existing_session or SessionContext(self.turn.session_id))
        turn_token = turn_var.set(self.turn)
        span_token = span_var.set(SpanContext(self.id, None, self.started_ns, self.name, self.logical_node_key))
        try:
            yield
        finally:
            span_var.reset(span_token)
            turn_var.reset(turn_token)
            session_var.reset(session_token)

    def finish(self, *, status: str = "ok", output: Any = None, capture_output: bool = True,
               error: BaseException | None = None, attributes: dict[str, Any] | None = None) -> None:
        if self.finished:
            return
        ended_ns = time.perf_counter_ns()
        ended_at = datetime.now(timezone.utc)
        output_value = self.recorder.capture(output) if capture_output else None
        super().finish(status=status, output=output, capture_output=capture_output, error=error, attributes=attributes)
        if self.disabled:
            return
        try:
            self.recorder.storage.finish_turn(
                turn_id=self.turn.id, status=status, ended_at=ended_at,
                duration_ns=ended_ns - self.started_ns, output_value=output_value,
            )
            self.recorder.storage.flush()
            self.recorder.maybe_cleanup()
        except Exception as exc:
            self._storage_error(exc)


class Recorder:
    def __init__(self, config: Config, storage: Any | None = None):
        if config.storage != "sqlite" and storage is None:
            raise ValueError(f"Storage '{config.storage}' requires a query backend plugin")
        self.config = config
        self.storage = storage or SQLiteStorage(config.sqlite_path)
        self.project_id = self.storage.ensure_project(config.project)
        self.redactor = Redactor(config.redaction)
        self._cleanup_lock = threading.Lock()
        self._last_cleanup_check = 0.0

    def capture(self, value: Any) -> SerializedValue:
        try:
            return self.redactor.redact_value(serialize(value))
        except Exception:
            if self.config.strict_mode:
                raise
            fallback = serialize({"python_type": type(value).__name__, "serialization_error": True})
            return self.redactor.redact_value(fallback)

    def capture_call(self, args: tuple[Any, ...], kwargs: dict[str, Any]) -> SerializedValue:
        try:
            return self.redactor.redact_value(serialize_call(args, kwargs))
        except Exception:
            if self.config.strict_mode:
                raise
            return self.capture({"serialization_error": True})

    def start_span(self, *, kind: SpanKind, name: str, logical_node_key: str, args: tuple[Any, ...],
                   kwargs: dict[str, Any], capture_input: bool, attributes: dict[str, Any] | None = None,
                   source: str = "decorator") -> Lifecycle:
        value = self.capture_call(args, kwargs) if capture_input else None
        return Lifecycle(self, kind=kind, name=name, logical_node_key=logical_node_key,
                         input_value=value, attributes=attributes, source=source)

    def start_turn(self, *, name: str, logical_node_key: str, session_id: str, args: tuple[Any, ...],
                   kwargs: dict[str, Any], capture_input: bool, attributes: dict[str, Any] | None = None) -> TurnLifecycle:
        value = self.capture_call(args, kwargs) if capture_input else None
        title_value = next((item for item in args if isinstance(item, str)), None)
        if title_value is None:
            title_value = value.content if value else name
        title, _ = self.redactor.redact_text(str(title_value))
        return TurnLifecycle(self, name=name, logical_node_key=logical_node_key, session_id=session_id,
                             input_value=value, title=title[:160], attributes=attributes)

    def maybe_cleanup(self) -> None:
        now = time.monotonic()
        if now - self._last_cleanup_check < 60 or not self._cleanup_lock.acquire(blocking=False):
            return
        try:
            self._last_cleanup_check = now
            self.storage.cleanup(
                max_age_days=self.config.retention.max_age_days,
                max_storage=self.config.retention.max_storage,
                keep_pinned=self.config.retention.keep_pinned,
                cleanup_target_ratio=self.config.retention.cleanup_target_ratio,
            )
        finally:
            self._cleanup_lock.release()

    def close(self) -> None:
        self.storage.flush()
        self.storage.close()
