from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal

SCHEMA_VERSION = "1.0"
SpanKind = Literal[
    "turn", "agent", "chain", "llm", "tool", "retriever", "handoff",
    "guardrail", "task", "custom",
]
SpanStatus = Literal["ok", "error", "incomplete", "cancelled", "unset"]


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class SerializedValue:
    content: str
    media_type: str
    serialization_error: bool = False
    redaction_count: int = 0
    truncated: bool = False


@dataclass(slots=True)
class SpanStart:
    span_id: str
    trace_id: str
    turn_id: str
    session_id: str
    project_id: str
    parent_span_id: str | None
    logical_node_key: str
    name: str
    kind: SpanKind
    start_sequence: int
    started_at: datetime
    input_value: SerializedValue | None
    attributes: dict[str, Any] = field(default_factory=dict)
    resource: dict[str, Any] = field(default_factory=dict)
    instrumentation_scope: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SpanEnd:
    span_id: str
    status: SpanStatus
    end_sequence: int
    ended_at: datetime
    duration_ns: int
    output_value: SerializedValue | None = None
    error_type: str | None = None
    error_message: str | None = None
    error_stack: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class LogRecordData:
    id: str
    project_id: str
    session_id: str
    turn_id: str
    trace_id: str
    span_id: str
    timestamp: datetime
    level: str
    logger_name: str
    message: str
    fields: dict[str, Any]
    exception: str | None
    source: str

