from __future__ import annotations

from typing import Any


def map_attributes(attributes: dict[str, Any] | None) -> tuple[str, str, dict[str, Any]]:
    values = dict(attributes or {})
    operation = values.get("gen_ai.operation.name") or values.get("agenttrace.span.kind") or "custom"
    kind_map = {"chat": "llm", "text_completion": "llm", "execute_tool": "tool", "invoke_agent": "agent"}
    kind = kind_map.get(str(operation), str(values.get("agenttrace.span.kind", "custom")))
    if kind not in {"turn", "agent", "chain", "llm", "tool", "retriever", "handoff", "guardrail", "task", "custom"}:
        kind = "custom"
    logical_key = str(values.get("agenttrace.logical_node.key") or values.get("gen_ai.request.model") or operation)
    return kind, logical_key, values

