from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("agenttrace.internal.otel")
_processors: dict[int, Any] = {}


def configure_otel(recorder: Any) -> bool:
    try:
        from opentelemetry import trace as otel_trace
        from opentelemetry.sdk.trace import TracerProvider
    except ImportError:
        return False
    from .processor import AgentTraceSpanProcessor
    provider = otel_trace.get_tracer_provider()
    if not hasattr(provider, "add_span_processor"):
        provider = TracerProvider()
        try:
            otel_trace.set_tracer_provider(provider)
        except Exception:
            provider = otel_trace.get_tracer_provider()
    key = id(provider)
    if key in _processors:
        return True
    try:
        processor = AgentTraceSpanProcessor(recorder)
        provider.add_span_processor(processor)
        _processors[key] = processor
        return True
    except Exception as exc:
        logger.warning("Cannot register AgentTrace OpenTelemetry processor: %s", exc)
        return False

