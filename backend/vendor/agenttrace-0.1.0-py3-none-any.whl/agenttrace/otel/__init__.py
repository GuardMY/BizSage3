from .provider import configure_otel

__all__ = ["configure_otel"]

