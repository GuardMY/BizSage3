from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from agenttrace.context import span_var, turn_var
from agenttrace.models import SpanEnd, SpanStart
from .mapping import map_attributes


class AgentTraceSpanProcessor:
    def __init__(self, recorder: Any):
        self.recorder = recorder
        self._started: set[str] = set()

    def on_start(self, span: Any, parent_context: Any = None) -> None:
        turn = turn_var.get()
        if turn is None:
            return
        identifier = format(span.get_span_context().span_id, "016x")
        if identifier in self._started:
            return
        kind, logical_key, attributes = map_attributes(getattr(span, "attributes", None))
        parent = span_var.get()
        self.recorder.storage.start_span(SpanStart(
            span_id=identifier, trace_id=turn.trace_id, turn_id=turn.id, session_id=turn.session_id,
            project_id=turn.project_id, parent_span_id=parent.id if parent else turn.root_span_id,
            logical_node_key=logical_key, name=span.name, kind=kind, start_sequence=turn.next_sequence(),
            started_at=datetime.now(timezone.utc), input_value=None, attributes=attributes,
            resource=dict(getattr(getattr(span, "resource", None), "attributes", {}) or {}),
            instrumentation_scope={"name": getattr(getattr(span, "instrumentation_scope", None), "name", "otel")},
        ))
        self._started.add(identifier)

    def on_end(self, span: Any) -> None:
        identifier = format(span.get_span_context().span_id, "016x")
        if identifier not in self._started:
            return
        turn = turn_var.get()
        if turn is None:
            return
        status_name = str(getattr(getattr(span, "status", None), "status_code", "")).lower()
        status = "error" if "error" in status_name else "ok"
        self.recorder.storage.end_span(SpanEnd(
            span_id=identifier, status=status, end_sequence=turn.next_sequence(), ended_at=datetime.now(timezone.utc),
            duration_ns=max(0, int((getattr(span, "end_time", 0) or 0) - (getattr(span, "start_time", 0) or 0))),
            error_message=getattr(getattr(span, "status", None), "description", None),
        ))
        self._started.discard(identifier)

    def shutdown(self) -> None:
        self.recorder.storage.flush()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        self.recorder.storage.flush(timeout_millis / 1000)
        return True
