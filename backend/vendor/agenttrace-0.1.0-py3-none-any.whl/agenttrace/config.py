from __future__ import annotations

import os
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from platformdirs import user_data_path

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python 3.10
    import tomli as tomllib


def _as_bool(value: str | bool) -> bool:
    if isinstance(value, bool):
        return value
    return value.strip().lower() in {"1", "true", "yes", "on"}


def parse_size(value: str | int) -> int:
    if isinstance(value, int):
        return value
    units = {"KB": 1024, "MB": 1024**2, "GB": 1024**3, "TB": 1024**4}
    normalized = value.strip().upper().replace(" ", "")
    for suffix, multiplier in units.items():
        if normalized.endswith(suffix):
            return int(float(normalized[: -len(suffix)]) * multiplier)
    return int(normalized)


@dataclass(slots=True)
class RetentionConfig:
    max_age_days: int = 30
    max_storage: int = 2 * 1024**3
    keep_pinned: bool = True
    cleanup_target_ratio: float = 0.8


@dataclass(slots=True)
class UIConfig:
    host: str = "127.0.0.1"
    port: int = 4319
    open_browser: bool = True


@dataclass(slots=True)
class RedactionConfig:
    enabled: bool = True
    field_paths: list[str] = field(default_factory=list)
    patterns: list[str] = field(default_factory=list)
    redactors: list[Any] = field(default_factory=list)


@dataclass(slots=True)
class Config:
    project: str = "default"
    storage: str = "sqlite"
    storage_url: str = ""
    capture_input: bool = True
    capture_output: bool = True
    strict_mode: bool = False
    auto_instrument: list[str] = field(default_factory=list)
    stdlib_logging: bool = True
    minimum_log_level: str = "INFO"
    retention: RetentionConfig = field(default_factory=RetentionConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    redaction: RedactionConfig = field(default_factory=RedactionConfig)

    @property
    def sqlite_path(self) -> Path:
        if self.storage_url:
            raw = self.storage_url
            if raw.startswith("sqlite:///"):
                raw = raw[10:]
            return Path(raw).expanduser().resolve()
        return user_data_path("AgentTrace", appauthor=False) / "agenttrace.db"


def _load_toml(path: Path | None) -> dict[str, Any]:
    if path is None:
        env_path = os.getenv("AGENTTRACE_CONFIG")
        path = Path(env_path) if env_path else user_data_path("AgentTrace", appauthor=False) / "config.toml"
    if not path.exists():
        return {}
    with path.open("rb") as handle:
        return tomllib.load(handle)


def load_config(path: Path | None = None, **overrides: Any) -> Config:
    data = _load_toml(path)
    root = data.get("agenttrace", {})
    instrumentation = data.get("instrumentation", {})
    logging = data.get("logging", {})
    retention = data.get("retention", {})
    ui = data.get("ui", {})
    redaction = data.get("redaction", {})
    cfg = Config(
        project=root.get("project", "default"),
        storage=root.get("storage", "sqlite"),
        storage_url=root.get("storage_url", ""),
        capture_input=root.get("capture_input", True),
        capture_output=root.get("capture_output", True),
        strict_mode=root.get("strict_mode", False),
        auto_instrument=list(instrumentation.get("enabled", [])),
        stdlib_logging=bool(logging.get("stdlib", True)),
        minimum_log_level=logging.get("minimum_level", "INFO"),
        retention=RetentionConfig(
            max_age_days=int(retention.get("max_age_days", 30)),
            max_storage=parse_size(retention.get("max_storage", "2GB")),
            keep_pinned=bool(retention.get("keep_pinned", True)),
            cleanup_target_ratio=float(retention.get("cleanup_target_ratio", 0.8)),
        ),
        ui=UIConfig(
            host=ui.get("host", "127.0.0.1"),
            port=int(ui.get("port", 4319)),
            open_browser=bool(ui.get("open_browser", True)),
        ),
        redaction=RedactionConfig(
            enabled=bool(redaction.get("enabled", True)),
            field_paths=list(redaction.get("field_paths", [])),
            patterns=list(redaction.get("patterns", [])),
        ),
    )
    env = os.environ
    scalar_env = {
        "project": env.get("AGENTTRACE_PROJECT"),
        "storage": env.get("AGENTTRACE_STORAGE"),
        "storage_url": env.get("AGENTTRACE_STORAGE_URL"),
        "capture_input": _as_bool(env["AGENTTRACE_CAPTURE_INPUT"]) if "AGENTTRACE_CAPTURE_INPUT" in env else None,
        "capture_output": _as_bool(env["AGENTTRACE_CAPTURE_OUTPUT"]) if "AGENTTRACE_CAPTURE_OUTPUT" in env else None,
    }
    for key, value in scalar_env.items():
        if value is not None:
            setattr(cfg, key, value)
    if env.get("AGENTTRACE_AUTO_INSTRUMENT"):
        cfg.auto_instrument = [item.strip() for item in env["AGENTTRACE_AUTO_INSTRUMENT"].split(",") if item.strip()]
    if env.get("AGENTTRACE_RETENTION_DAYS"):
        cfg.retention.max_age_days = int(env["AGENTTRACE_RETENTION_DAYS"])
    if env.get("AGENTTRACE_MAX_STORAGE"):
        cfg.retention.max_storage = parse_size(env["AGENTTRACE_MAX_STORAGE"])
    if env.get("AGENTTRACE_UI_PORT"):
        cfg.ui.port = int(env["AGENTTRACE_UI_PORT"])

    nested = {"retention", "ui", "redaction"}
    for key, value in overrides.items():
        if value is None:
            continue
        if key in nested and isinstance(value, dict):
            current = getattr(cfg, key)
            valid = {name: item for name, item in value.items() if hasattr(current, name)}
            setattr(cfg, key, replace(current, **valid))
        elif hasattr(cfg, key):
            setattr(cfg, key, value)
    return cfg
