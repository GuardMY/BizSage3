from __future__ import annotations

import contextvars
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar

T = TypeVar("T")


@dataclass(slots=True)
class SessionContext:
    id: str


@dataclass(slots=True)
class TurnContext:
    id: str
    session_id: str
    trace_id: str
    project_id: str
    root_span_id: str
    sequence: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock)
    last_completed_by_parent: dict[str, tuple[str, int]] = field(default_factory=dict)

    def next_sequence(self) -> int:
        with self.lock:
            self.sequence += 1
            return self.sequence


@dataclass(slots=True)
class SpanContext:
    id: str
    parent_id: str | None
    started_ns: int
    name: str
    logical_node_key: str


session_var: contextvars.ContextVar[SessionContext | None] = contextvars.ContextVar("agenttrace_session", default=None)
turn_var: contextvars.ContextVar[TurnContext | None] = contextvars.ContextVar("agenttrace_turn", default=None)
span_var: contextvars.ContextVar[SpanContext | None] = contextvars.ContextVar("agenttrace_span", default=None)


def current_context() -> dict[str, str]:
    session, turn, span = session_var.get(), turn_var.get(), span_var.get()
    if not (session and turn and span):
        return {}
    return {
        "project_id": turn.project_id,
        "session_id": session.id,
        "turn_id": turn.id,
        "trace_id": turn.trace_id,
        "span_id": span.id,
    }


def copy_context_call(fn: Callable[..., T], *args: Any, **kwargs: Any) -> Callable[[], T]:
    context = contextvars.copy_context()
    return lambda: context.run(fn, *args, **kwargs)
