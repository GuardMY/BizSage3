from __future__ import annotations

import json
import re
from dataclasses import replace
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .config import RedactionConfig
from .models import SerializedValue

REDACTED = "[REDACTED]"
SENSITIVE_FIELDS = re.compile(
    r"^(authorization|proxy-authorization|api[_-]?key|access[_-]?token|refresh[_-]?token|"
    r"id[_-]?token|password|passwd|secret|cookie|set-cookie|private[_-]?key|client[_-]?secret)$",
    re.IGNORECASE,
)
CONTENT_PATTERNS = [
    re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{8,}"),
    re.compile(r"\b(?:sk|rk|pk|api)[-_][A-Za-z0-9_-]{16,}\b", re.IGNORECASE),
    re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b"),
    re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE),
    re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"),
    re.compile(r"(?<!\d)\d{6}(?:18|19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[0-9Xx](?!\d)"),
    re.compile(r"(?<!\d)(?:\d[ -]?){15,18}\d(?!\d)"),
]


class Redactor:
    def __init__(self, config: RedactionConfig | None = None):
        self.config = config or RedactionConfig()
        self.user_patterns = [re.compile(pattern) for pattern in self.config.patterns]
        self.field_paths = {path.removeprefix("$.") for path in self.config.field_paths}

    def _redact_url(self, text: str) -> tuple[str, int]:
        if not (text.startswith("http://") or text.startswith("https://")):
            return text, 0
        try:
            parts = urlsplit(text)
            pairs = parse_qsl(parts.query, keep_blank_values=True)
            changed = 0
            clean = []
            for key, value in pairs:
                if SENSITIVE_FIELDS.match(key):
                    clean.append((key, REDACTED))
                    changed += 1
                else:
                    clean.append((key, value))
            return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(clean), parts.fragment)), changed
        except ValueError:
            return text, 0

    def redact_text(self, text: str) -> tuple[str, int]:
        if not self.config.enabled:
            return text, 0
        result, count = self._redact_url(text)
        for pattern in [*CONTENT_PATTERNS, *self.user_patterns]:
            result, hits = pattern.subn(REDACTED, result)
            count += hits
        return result, count

    def _walk(self, value: Any, path: str = "") -> tuple[Any, int]:
        if isinstance(value, dict):
            result: dict[str, Any] = {}
            total = 0
            for key, item in value.items():
                item_path = f"{path}.{key}" if path else str(key)
                if item_path in self.field_paths or SENSITIVE_FIELDS.match(str(key)):
                    result[key] = REDACTED
                    total += 1
                else:
                    result[key], hits = self._walk(item, item_path)
                    total += hits
            return result, total
        if isinstance(value, list):
            result = []
            total = 0
            for index, item in enumerate(value):
                clean, hits = self._walk(item, f"{path}.{index}" if path else str(index))
                result.append(clean)
                total += hits
            return result, total
        if isinstance(value, str):
            return self.redact_text(value)
        return value, 0

    def redact_value(self, value: SerializedValue) -> SerializedValue:
        if not self.config.enabled:
            return value
        if value.media_type == "application/json":
            try:
                parsed = json.loads(value.content)
                parsed, count = self._walk(parsed)
                for custom in self.config.redactors:
                    parsed = custom(parsed)
                content = json.dumps(parsed, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
                return replace(value, content=content, redaction_count=value.redaction_count + count)
            except (TypeError, ValueError):
                pass
        content, count = self.redact_text(value.content)
        for custom in self.config.redactors:
            content = custom(content)
        return replace(value, content=content, redaction_count=value.redaction_count + count)
