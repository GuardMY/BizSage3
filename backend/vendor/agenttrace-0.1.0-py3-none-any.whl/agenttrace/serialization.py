from __future__ import annotations

import dataclasses
import json
from datetime import date, datetime, time
from enum import Enum
from pathlib import Path
from typing import Any
from uuid import UUID

from .models import SerializedValue


def _safe_value(value: Any, seen: set[int]) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"python_type": type(value).__name__, "binary_size": len(value), "serialization_error": True}
    identity = id(value)
    if identity in seen:
        return {"python_type": type(value).__name__, "value": "<recursive>", "serialization_error": True}
    seen.add(identity)
    try:
        if dataclasses.is_dataclass(value) and not isinstance(value, type):
            return {field.name: _safe_value(getattr(value, field.name), seen) for field in dataclasses.fields(value)}
        if isinstance(value, dict):
            return {str(key): _safe_value(item, seen) for key, item in value.items()}
        if isinstance(value, (list, tuple, set, frozenset)):
            return [_safe_value(item, seen) for item in value]
        if isinstance(value, Enum):
            return _safe_value(value.value, seen)
        if isinstance(value, (datetime, date, time)):
            return value.isoformat()
        if isinstance(value, UUID):
            return str(value)
        if isinstance(value, Path):
            return {"python_type": type(value).__name__, "value": str(value), "serialization_error": True}
        if hasattr(value, "model_dump") and callable(value.model_dump):
            return _safe_value(value.model_dump(mode="json"), seen)
        try:
            text = repr(value)
        except Exception:
            text = "<unrepresentable>"
        return {
            "python_type": f"{type(value).__module__}.{type(value).__qualname__}",
            "value": text[:1000],
            "serialization_error": True,
        }
    finally:
        seen.discard(identity)


def serialize(value: Any) -> SerializedValue:
    if isinstance(value, str):
        return SerializedValue(content=value, media_type="text/plain")
    safe = _safe_value(value, set())
    content = json.dumps(safe, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return SerializedValue(
        content=content,
        media_type="application/json",
        serialization_error="serialization_error" in content,
    )


def serialize_call(args: tuple[Any, ...], kwargs: dict[str, Any]) -> SerializedValue:
    return serialize({"args": list(args), "kwargs": kwargs})

