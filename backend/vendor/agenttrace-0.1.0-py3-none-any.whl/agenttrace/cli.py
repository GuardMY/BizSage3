from __future__ import annotations

import argparse
import socket
import threading
import webbrowser
from typing import Sequence

import uvicorn

from .config import load_config
from .server import create_app


def _available_port(host: str, preferred: int) -> int:
    for port in range(preferred, min(preferred + 100, 65536)):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind((host, port))
                return port
            except OSError:
                continue
    raise RuntimeError("未找到可用端口")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="agenttrace", description="AgentTrace 本地调用链排查工具")
    subparsers = parser.add_subparsers(dest="command", required=True)
    ui = subparsers.add_parser("ui", help="启动本地 Web 工作台")
    ui.add_argument("--host", default=None)
    ui.add_argument("--port", type=int, default=None)
    ui.add_argument("--storage", default=None, help="SQLite URL，例如 sqlite:///path/to/agenttrace.db")
    ui.add_argument("--no-open", action="store_true", help="不自动打开浏览器")
    ui.add_argument("--config", default=None, help="TOML 配置路径")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "ui":
        overrides = {"storage_url": args.storage} if args.storage else {}
        cfg = load_config(args.config, **overrides)
        host = args.host or cfg.ui.host
        if host not in {"127.0.0.1", "localhost", "::1"}:
            raise SystemExit("出于安全考虑，V1 默认只允许本机回环地址")
        port = _available_port(host, args.port or cfg.ui.port)
        url = f"http://{host}:{port}"
        print(f"AgentTrace: {url}")
        print(f"Storage: {cfg.sqlite_path}")
        if not args.no_open and cfg.ui.open_browser:
            threading.Timer(0.8, lambda: webbrowser.open(url)).start()
        uvicorn.run(create_app(config=cfg), host=host, port=port, log_level="info")
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

