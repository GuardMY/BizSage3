"""AgentTrace public API."""

from .api import TraceAPI, trace

__all__ = ["TraceAPI", "trace"]
__version__ = "0.1.0"

