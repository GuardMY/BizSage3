"""Bundled AgentTrace web assets."""
