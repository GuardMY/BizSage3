from __future__ import annotations

import atexit
import contextlib
import threading
from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any

from .config import Config, load_config
from .context import SessionContext, current_context, session_var
from .decorators import decorate
from .runtime.recorder import Recorder, uuid7


class SessionHandle:
    def __init__(self, session_id: str):
        self.id = session_id


class TraceAPI:
    def __init__(self):
        self._lock = threading.RLock()
        self._config: Config | None = None
        self._recorder: Recorder | None = None
        atexit.register(self._shutdown)

    @property
    def config(self) -> Config:
        if self._config is None:
            self._config = load_config()
        return self._config

    @property
    def recorder(self) -> Recorder:
        with self._lock:
            if self._recorder is None:
                try:
                    self._recorder = Recorder(self.config)
                except Exception:
                    if self.config.strict_mode:
                        raise
                    from .runtime.recorder import internal_logger
                    from .storage.noop import NoOpStorage
                    internal_logger.exception("AgentTrace storage initialization failed; capture is disabled")
                    self._recorder = Recorder(self.config, storage=NoOpStorage())
            return self._recorder

    @property
    def storage(self):
        return self.recorder.storage

    def configure(self, *, config_path: str | Path | None = None, **options: Any) -> Config:
        with self._lock:
            if self._recorder is not None:
                self._recorder.close()
                self._recorder = None
            self._config = load_config(Path(config_path) if config_path else None, **options)
            _ = self.recorder
            if self._config.stdlib_logging:
                from .logging import install_logging_handler
                install_logging_handler(self._config.minimum_log_level)
            try:
                from .otel import configure_otel
                configure_otel(self.recorder)
            except Exception:
                if self._config.strict_mode:
                    raise
            self._configure_integrations()
            return self._config

    def _configure_integrations(self) -> None:
        if not self.config.auto_instrument:
            return
        from .integrations import instrument
        instrument(self.config.auto_instrument, strict=self.config.strict_mode)

    def _shutdown(self) -> None:
        with self._lock:
            if self._recorder is not None:
                try:
                    self._recorder.close()
                except Exception:
                    pass
                self._recorder = None

    def flush(self, timeout: float | None = None) -> None:
        self.recorder.storage.flush(timeout)

    @contextlib.contextmanager
    def session(self, session_id: str | None = None) -> Iterator[SessionHandle]:
        handle = SessionHandle(session_id or uuid7())
        token = session_var.set(SessionContext(handle.id))
        try:
            yield handle
        finally:
            session_var.reset(token)

    def context(self) -> dict[str, str]:
        return current_context()

    def _decorator(self, kind: str, *, name: str | None = None, node_key: str | None = None,
                   capture_input: bool | None = None, capture_output: bool | None = None,
                   tags: list[str] | None = None, attributes: dict[str, Any] | None = None,
                   session_id: str | Callable[..., str] | None = None):
        def factory(fn: Callable[..., Any]) -> Callable[..., Any]:
            return decorate(
                lambda: self.recorder, fn, kind=kind, name=name, node_key=node_key,
                capture_input=self.config.capture_input if capture_input is None else capture_input,
                capture_output=self.config.capture_output if capture_output is None else capture_output,
                attributes=attributes, tags=tags, session_id=session_id,
            )
        return factory

    def turn(self, **kwargs: Any): return self._decorator("turn", **kwargs)
    def agent(self, **kwargs: Any): return self._decorator("agent", **kwargs)
    def chain(self, **kwargs: Any): return self._decorator("chain", **kwargs)
    def llm(self, **kwargs: Any): return self._decorator("llm", **kwargs)
    def tool(self, **kwargs: Any): return self._decorator("tool", **kwargs)
    def retriever(self, **kwargs: Any): return self._decorator("retriever", **kwargs)
    def handoff(self, **kwargs: Any): return self._decorator("handoff", **kwargs)
    def guardrail(self, **kwargs: Any): return self._decorator("guardrail", **kwargs)
    def task(self, **kwargs: Any): return self._decorator("task", **kwargs)

    def node(self, *, kind: str = "custom", **kwargs: Any):
        return self._decorator(kind, **kwargs)


trace = TraceAPI()
