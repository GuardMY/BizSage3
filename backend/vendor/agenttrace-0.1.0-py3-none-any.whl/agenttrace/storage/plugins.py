from __future__ import annotations

import importlib.metadata
from typing import Any


def discover(group: str) -> dict[str, Any]:
    return {entry.name: entry.load() for entry in importlib.metadata.entry_points(group=group)}


def storage_plugins() -> dict[str, dict[str, Any]]:
    return {
        "writers": discover("agenttrace.storage_writers"),
        "query_backends": discover("agenttrace.query_backends"),
    }
