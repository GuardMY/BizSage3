from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from uuid import uuid4

from agenttrace.models import LogRecordData, SCHEMA_VERSION, SerializedValue, SpanEnd, SpanStart
from agenttrace.runtime.graph_builder import build_aggregated, build_expanded, merge_history

SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_info (version TEXT NOT NULL, migrated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY, service_name TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
  created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'incomplete',
  turn_count INTEGER NOT NULL DEFAULT 0, span_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0, pinned INTEGER NOT NULL DEFAULT 0,
  started_at TEXT NOT NULL, ended_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS turns (
  id TEXT PRIMARY KEY, session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  sequence INTEGER NOT NULL, trace_id TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'incomplete',
  input_payload_id TEXT, output_payload_id TEXT, started_at TEXT NOT NULL, ended_at TEXT,
  duration_ns INTEGER, root_span_id TEXT
);
CREATE TABLE IF NOT EXISTS traces (
  trace_id TEXT PRIMARY KEY, turn_id TEXT NOT NULL REFERENCES turns(id) ON DELETE CASCADE,
  root_span_id TEXT NOT NULL, span_count INTEGER NOT NULL DEFAULT 0, error_count INTEGER NOT NULL DEFAULT 0,
  started_at TEXT NOT NULL, ended_at TEXT, completed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS payloads (
  id TEXT PRIMARY KEY, media_type TEXT NOT NULL, encoding TEXT NOT NULL DEFAULT 'utf-8',
  compression TEXT NOT NULL DEFAULT 'none', content BLOB NOT NULL, content_hash TEXT NOT NULL,
  original_size INTEGER NOT NULL, stored_size INTEGER NOT NULL, truncated INTEGER NOT NULL DEFAULT 0,
  redaction_count INTEGER NOT NULL DEFAULT 0, serialization_error INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS spans (
  span_id TEXT PRIMARY KEY, trace_id TEXT NOT NULL REFERENCES traces(trace_id) ON DELETE CASCADE,
  turn_id TEXT NOT NULL REFERENCES turns(id) ON DELETE CASCADE, parent_span_id TEXT,
  logical_node_key TEXT NOT NULL, name TEXT NOT NULL, kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'unset', start_sequence INTEGER NOT NULL, end_sequence INTEGER,
  started_at TEXT NOT NULL, ended_at TEXT, duration_ns INTEGER, input_payload_id TEXT,
  output_payload_id TEXT, attributes TEXT NOT NULL DEFAULT '{}', resource TEXT NOT NULL DEFAULT '{}',
  instrumentation_scope TEXT NOT NULL DEFAULT '{}', error_type TEXT, error_message TEXT, error_stack TEXT
);
CREATE TABLE IF NOT EXISTS span_predecessors (
  span_id TEXT NOT NULL REFERENCES spans(span_id) ON DELETE CASCADE,
  predecessor_span_id TEXT NOT NULL REFERENCES spans(span_id) ON DELETE CASCADE,
  relation TEXT NOT NULL, confidence TEXT NOT NULL, PRIMARY KEY(span_id, predecessor_span_id, relation)
);
CREATE TABLE IF NOT EXISTS log_records (
  id TEXT PRIMARY KEY, project_id TEXT NOT NULL, session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  turn_id TEXT NOT NULL REFERENCES turns(id) ON DELETE CASCADE, trace_id TEXT NOT NULL,
  span_id TEXT NOT NULL REFERENCES spans(span_id) ON DELETE CASCADE, timestamp TEXT NOT NULL,
  level TEXT NOT NULL, logger_name TEXT NOT NULL, message TEXT NOT NULL, fields TEXT NOT NULL DEFAULT '{}',
  exception TEXT, source TEXT NOT NULL, event_key TEXT UNIQUE
);
CREATE TABLE IF NOT EXISTS graph_projection_cache (
  turn_id TEXT NOT NULL REFERENCES turns(id) ON DELETE CASCADE, projection_type TEXT NOT NULL,
  source_revision INTEGER NOT NULL, node_count INTEGER NOT NULL, edge_count INTEGER NOT NULL,
  projection_json TEXT NOT NULL, generated_at TEXT NOT NULL, PRIMARY KEY(turn_id, projection_type)
);
CREATE TABLE IF NOT EXISTS search_documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT NOT NULL,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  turn_id TEXT NOT NULL, span_id TEXT NOT NULL, hit_type TEXT NOT NULL,
  content TEXT NOT NULL, timestamp TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS storage_events (
  key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_project_time ON sessions(project_id, updated_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_turns_session_sequence ON turns(session_id, sequence);
CREATE INDEX IF NOT EXISTS idx_spans_turn_sequence ON spans(turn_id, start_sequence, span_id);
CREATE INDEX IF NOT EXISTS idx_spans_trace ON spans(trace_id);
CREATE INDEX IF NOT EXISTS idx_spans_logical ON spans(turn_id, logical_node_key);
CREATE INDEX IF NOT EXISTS idx_logs_span_time ON log_records(span_id, timestamp, id);
CREATE INDEX IF NOT EXISTS idx_payload_hash ON payloads(content_hash);
CREATE INDEX IF NOT EXISTS idx_search_documents_project ON search_documents(project_id, timestamp DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_search_documents_session ON search_documents(session_id);
"""


def _iso(value: datetime | str | None) -> str | None:
    if value is None or isinstance(value, str):
        return value
    return value.astimezone(timezone.utc).isoformat()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


class SQLiteStorage:
    capabilities = {"write", "query", "search", "retention", "graph_cache"}

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, timeout=5, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript(SCHEMA)
        if not self._conn.execute("SELECT 1 FROM schema_info LIMIT 1").fetchone():
            self._conn.execute("INSERT INTO schema_info(version,migrated_at) VALUES (?,?)", (SCHEMA_VERSION, _iso(datetime.now(timezone.utc))))
        self.fts_tokenizer = self._ensure_fts()
        self._conn.commit()

    def _ensure_fts(self) -> str | None:
        existing = self._conn.execute("SELECT sql FROM sqlite_master WHERE name='search_index'").fetchone()
        if existing:
            sql = existing[0] or ""
            return "trigram" if "trigram" in sql else "unicode61"
        for tokenizer in ("trigram", "unicode61"):
            try:
                self._conn.execute(
                    "CREATE VIRTUAL TABLE search_index USING fts5(project_id UNINDEXED, session_id UNINDEXED, "
                    "turn_id UNINDEXED, span_id UNINDEXED, hit_type UNINDEXED, content, timestamp UNINDEXED, "
                    f"tokenize='{tokenizer}')"
                )
                return tokenizer
            except sqlite3.OperationalError:
                continue
        return None

    def _row(self, row: sqlite3.Row | None) -> dict[str, Any] | None:
        return dict(row) if row else None

    def _payload(self, value: SerializedValue | None) -> str | None:
        if value is None:
            return None
        payload_id = str(uuid4())
        content = value.content.encode("utf-8")
        self._conn.execute(
            "INSERT INTO payloads(id,media_type,content,content_hash,original_size,stored_size,truncated,"
            "redaction_count,serialization_error,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (payload_id, value.media_type, content, hashlib.sha256(content).hexdigest(), len(content), len(content),
             int(value.truncated), value.redaction_count, int(value.serialization_error), _iso(datetime.now(timezone.utc))),
        )
        return payload_id

    def _index(self, project_id: str, session_id: str, turn_id: str, span_id: str, hit_type: str, content: str, timestamp: str) -> None:
        if not content:
            return
        self._conn.execute(
            "INSERT INTO search_documents(project_id,session_id,turn_id,span_id,hit_type,content,timestamp) VALUES (?,?,?,?,?,?,?)",
            (project_id, session_id, turn_id, span_id, hit_type, content, timestamp),
        )
        if self.fts_tokenizer:
            self._conn.execute(
                "INSERT INTO search_index(project_id,session_id,turn_id,span_id,hit_type,content,timestamp) VALUES (?,?,?,?,?,?,?)",
                (project_id, session_id, turn_id, span_id, hit_type, content, timestamp),
            )

    def ensure_project(self, service_name: str) -> str:
        now = _iso(datetime.now(timezone.utc))
        with self._lock:
            row = self._conn.execute("SELECT id FROM projects WHERE service_name=?", (service_name,)).fetchone()
            if row:
                self._conn.execute("UPDATE projects SET last_seen_at=? WHERE id=?", (now, row[0]))
                self._conn.commit()
                return str(row[0])
            project_id = str(uuid4())
            self._conn.execute(
                "INSERT INTO projects(id,service_name,display_name,created_at,last_seen_at) VALUES (?,?,?,?,?)",
                (project_id, service_name, service_name, now, now),
            )
            self._conn.commit()
            return project_id

    def begin_turn(self, *, project_id: str, session_id: str, turn_id: str, trace_id: str, root_span_id: str,
                   title: str, started_at: datetime, input_value: SerializedValue | None) -> int:
        started = _iso(started_at)
        now = _iso(datetime.now(timezone.utc))
        with self._lock:
            session = self._conn.execute("SELECT id FROM sessions WHERE id=?", (session_id,)).fetchone()
            if not session:
                self._conn.execute(
                    "INSERT INTO sessions(id,project_id,title,status,started_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
                    (session_id, project_id, title[:160], "incomplete", started, now, now),
                )
            else:
                owner = self._conn.execute("SELECT project_id FROM sessions WHERE id=?", (session_id,)).fetchone()[0]
                if owner != project_id:
                    raise ValueError("session_id already belongs to another project")
            sequence = int(self._conn.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM turns WHERE session_id=?", (session_id,)).fetchone()[0])
            payload_id = self._payload(input_value)
            self._conn.execute(
                "INSERT INTO turns(id,session_id,sequence,trace_id,status,input_payload_id,started_at,root_span_id) VALUES (?,?,?,?,?,?,?,?)",
                (turn_id, session_id, sequence, trace_id, "incomplete", payload_id, started, root_span_id),
            )
            self._conn.execute(
                "INSERT INTO traces(trace_id,turn_id,root_span_id,started_at) VALUES (?,?,?,?)",
                (trace_id, turn_id, root_span_id, started),
            )
            self._conn.execute("UPDATE sessions SET turn_count=turn_count+1,updated_at=? WHERE id=?", (now, session_id))
            if input_value:
                self._index(project_id, session_id, turn_id, root_span_id, "用户输入", input_value.content, started or now)
            self._conn.commit()
            return sequence

    def start_span(self, record: SpanStart) -> None:
        with self._lock:
            input_id = self._payload(record.input_value)
            self._conn.execute(
                "INSERT INTO spans(span_id,trace_id,turn_id,parent_span_id,logical_node_key,name,kind,status,start_sequence,"
                "started_at,input_payload_id,attributes,resource,instrumentation_scope) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (record.span_id, record.trace_id, record.turn_id, record.parent_span_id, record.logical_node_key,
                 record.name, record.kind, "unset", record.start_sequence, _iso(record.started_at), input_id,
                 _json(record.attributes), _json(record.resource), _json(record.instrumentation_scope)),
            )
            self._conn.execute("UPDATE traces SET span_count=span_count+1 WHERE trace_id=?", (record.trace_id,))
            self._conn.execute("UPDATE sessions SET span_count=span_count+1,updated_at=? WHERE id=?", (_iso(record.started_at), record.session_id))
            if record.input_value:
                hit_type = "用户输入" if record.kind == "turn" else "节点输入"
                self._index(record.project_id, record.session_id, record.turn_id, record.span_id, hit_type, record.input_value.content, _iso(record.started_at) or "")
            self._index(record.project_id, record.session_id, record.turn_id, record.span_id, "节点名称", record.name, _iso(record.started_at) or "")
            self._conn.execute("DELETE FROM graph_projection_cache WHERE turn_id=?", (record.turn_id,))
            if record.kind == "turn":
                self._conn.commit()

    def add_predecessor(self, span_id: str, predecessor_span_id: str, relation: str = "runtime", confidence: str = "observed") -> None:
        if span_id == predecessor_span_id:
            return
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO span_predecessors(span_id,predecessor_span_id,relation,confidence) VALUES (?,?,?,?)",
                (span_id, predecessor_span_id, relation, confidence),
            )

    def end_span(self, record: SpanEnd) -> None:
        with self._lock:
            output_id = self._payload(record.output_value)
            row = self._conn.execute(
                "SELECT s.turn_id,t.session_id,se.project_id FROM spans s JOIN turns t ON t.id=s.turn_id "
                "JOIN sessions se ON se.id=t.session_id WHERE s.span_id=?", (record.span_id,),
            ).fetchone()
            if not row:
                return
            attributes = self._conn.execute("SELECT attributes FROM spans WHERE span_id=?", (record.span_id,)).fetchone()[0]
            merged = json.loads(attributes)
            merged.update(record.attributes)
            self._conn.execute(
                "UPDATE spans SET status=?,end_sequence=?,ended_at=?,duration_ns=?,output_payload_id=?,attributes=?,"
                "error_type=?,error_message=?,error_stack=? WHERE span_id=?",
                (record.status, record.end_sequence, _iso(record.ended_at), record.duration_ns, output_id, _json(merged),
                 record.error_type, record.error_message, record.error_stack, record.span_id),
            )
            if record.status == "error":
                self._conn.execute("UPDATE traces SET error_count=error_count+1 WHERE turn_id=?", (row["turn_id"],))
                self._conn.execute("UPDATE sessions SET error_count=error_count+1 WHERE id=?", (row["session_id"],))
            if record.output_value:
                self._index(row["project_id"], row["session_id"], row["turn_id"], record.span_id, "节点输出", record.output_value.content, _iso(record.ended_at) or "")
            if record.error_message:
                self._index(row["project_id"], row["session_id"], row["turn_id"], record.span_id, "异常", f"{record.error_type or ''} {record.error_message} {record.error_stack or ''}", _iso(record.ended_at) or "")
            self._conn.execute("DELETE FROM graph_projection_cache WHERE turn_id=?", (row["turn_id"],))

    def finish_turn(self, *, turn_id: str, status: str, ended_at: datetime, duration_ns: int,
                    output_value: SerializedValue | None) -> None:
        with self._lock:
            row = self._conn.execute(
                "SELECT t.trace_id,t.session_id,t.root_span_id,s.project_id FROM turns t JOIN sessions s ON s.id=t.session_id WHERE t.id=?",
                (turn_id,),
            ).fetchone()
            if not row:
                return
            output_id = self._payload(output_value)
            ended = _iso(ended_at)
            self._conn.execute(
                "UPDATE turns SET status=?,ended_at=?,duration_ns=?,output_payload_id=? WHERE id=?",
                (status, ended, duration_ns, output_id, turn_id),
            )
            self._conn.execute(
                "UPDATE traces SET ended_at=?,completed=? WHERE turn_id=?", (ended, int(status not in {"incomplete"}), turn_id),
            )
            session_status = "error" if status == "error" else "incomplete" if status in {"incomplete", "cancelled"} else "success"
            all_turns = self._conn.execute("SELECT status FROM turns WHERE session_id=?", (row["session_id"],)).fetchall()
            statuses = {item[0] for item in all_turns}
            if "error" in statuses and len(statuses) > 1:
                session_status = "partial_error"
            elif "error" in statuses:
                session_status = "error"
            elif statuses & {"incomplete", "cancelled"}:
                session_status = "incomplete"
            self._conn.execute(
                "UPDATE sessions SET status=?,ended_at=?,updated_at=? WHERE id=?",
                (session_status, ended, ended, row["session_id"]),
            )
            if output_value:
                self._index(row["project_id"], row["session_id"], turn_id, row["root_span_id"], "最终输出", output_value.content, ended or "")
            self._conn.commit()

    def write_log(self, record: LogRecordData, event_key: str | None = None) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO log_records(id,project_id,session_id,turn_id,trace_id,span_id,timestamp,level,"
                "logger_name,message,fields,exception,source,event_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (record.id, record.project_id, record.session_id, record.turn_id, record.trace_id, record.span_id,
                 _iso(record.timestamp), record.level, record.logger_name, record.message, _json(record.fields),
                 record.exception, record.source, event_key),
            )
            self._index(record.project_id, record.session_id, record.turn_id, record.span_id, "日志", f"{record.message} {record.exception or ''} {_json(record.fields)}", _iso(record.timestamp) or "")

    def flush(self, timeout: float | None = None) -> None:
        with self._lock:
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.commit()
            self._conn.close()

    def list_projects(self) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT p.*,COUNT(DISTINCT s.id) session_count,COUNT(DISTINCT t.id) turn_count,COUNT(DISTINCT sp.span_id) span_count "
                "FROM projects p LEFT JOIN sessions s ON s.project_id=p.id LEFT JOIN turns t ON t.session_id=s.id "
                "LEFT JOIN spans sp ON sp.turn_id=t.id GROUP BY p.id ORDER BY p.last_seen_at DESC"
            ).fetchall()
            return [dict(row) for row in rows]

    def list_sessions(self, *, project_id: str, limit: int = 50, cursor: str | None = None, status: str | None = None,
                      contains_error: bool | None = None, pinned: bool | None = None, kind: str | None = None,
                      query: str | None = None, **_: Any) -> dict[str, Any]:
        clauses = ["s.project_id=?"]
        params: list[Any] = [project_id]
        if cursor:
            timestamp, session_id = cursor.split("|", 1)
            clauses.append("(s.updated_at < ? OR (s.updated_at=? AND s.id<?))")
            params.extend([timestamp, timestamp, session_id])
        if status:
            clauses.append("s.status=?")
            params.append(status)
        if contains_error is not None:
            clauses.append("s.error_count > 0" if contains_error else "s.error_count=0")
        if pinned is not None:
            clauses.append("s.pinned=?")
            params.append(int(pinned))
        if kind:
            clauses.append("EXISTS(SELECT 1 FROM turns t JOIN spans sp ON sp.turn_id=t.id WHERE t.session_id=s.id AND sp.kind=?)")
            params.append(kind)
        if query:
            clauses.append("(s.title LIKE ? OR s.id LIKE ?)")
            params.extend([f"%{query}%", f"%{query}%"])
        params.append(min(max(limit, 1), 200) + 1)
        with self._lock:
            rows = self._conn.execute(
                "SELECT s.* FROM sessions s WHERE " + " AND ".join(clauses) + " ORDER BY s.updated_at DESC,s.id DESC LIMIT ?",
                params,
            ).fetchall()
        has_more = len(rows) > limit
        items = [dict(row) for row in rows[:limit]]
        next_cursor = f"{items[-1]['updated_at']}|{items[-1]['id']}" if has_more and items else None
        return {"items": items, "next_cursor": next_cursor}

    def _get_payload(self, payload_id: str | None) -> dict[str, Any] | None:
        if not payload_id:
            return None
        row = self._conn.execute("SELECT * FROM payloads WHERE id=?", (payload_id,)).fetchone()
        if not row:
            return None
        result = dict(row)
        raw = result["content"]
        result["content"] = bytes(raw).decode("utf-8") if not isinstance(raw, str) else raw
        return result

    def get_session(self, session_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT s.*,p.service_name,p.display_name project_name FROM sessions s JOIN projects p ON p.id=s.project_id WHERE s.id=?",
                (session_id,),
            ).fetchone()
            if not row:
                return None
            result = dict(row)
            result["turns"] = [dict(item) for item in self._conn.execute(
                "SELECT id,session_id,sequence,trace_id,status,started_at,ended_at,duration_ns,root_span_id FROM turns WHERE session_id=? ORDER BY sequence",
                (session_id,),
            ).fetchall()]
            return result

    def set_pinned(self, session_id: str, pinned: bool) -> bool:
        with self._lock:
            cursor = self._conn.execute("UPDATE sessions SET pinned=?,updated_at=? WHERE id=?", (int(pinned), _iso(datetime.now(timezone.utc)), session_id))
            self._conn.commit()
            return cursor.rowcount > 0

    def delete_session(self, session_id: str) -> bool:
        with self._lock:
            if self.fts_tokenizer:
                self._conn.execute("DELETE FROM search_index WHERE session_id=?", (session_id,))
            cursor = self._conn.execute("DELETE FROM sessions WHERE id=?", (session_id,))
            self._delete_orphan_payloads()
            self._conn.commit()
            return cursor.rowcount > 0

    def _logical_size(self) -> int:
        page_count = int(self._conn.execute("PRAGMA page_count").fetchone()[0])
        free_count = int(self._conn.execute("PRAGMA freelist_count").fetchone()[0])
        page_size = int(self._conn.execute("PRAGMA page_size").fetchone()[0])
        wal_path = Path(str(self.path) + "-wal")
        wal_size = wal_path.stat().st_size if wal_path.exists() else 0
        return max(0, page_count - free_count) * page_size + wal_size

    def list_turns(self, session_id: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM turns WHERE session_id=? ORDER BY sequence", (session_id,)).fetchall()
            return [dict(row) for row in rows]

    def _graph_source(self, turn_id: str) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
        turn_row = self._conn.execute("SELECT * FROM turns WHERE id=?", (turn_id,)).fetchone()
        if not turn_row:
            raise KeyError(turn_id)
        span_rows = self._conn.execute(
            "SELECT s.*,(SELECT COUNT(*) FROM log_records l WHERE l.span_id=s.span_id) log_count FROM spans s WHERE s.turn_id=? ORDER BY s.start_sequence",
            (turn_id,),
        ).fetchall()
        spans = []
        for row in span_rows:
            item = dict(row)
            item["attributes"] = json.loads(item["attributes"] or "{}")
            item["resource"] = json.loads(item["resource"] or "{}")
            item["instrumentation_scope"] = json.loads(item["instrumentation_scope"] or "{}")
            spans.append(item)
        predecessors = [dict(row) for row in self._conn.execute(
            "SELECT p.* FROM span_predecessors p JOIN spans s ON s.span_id=p.span_id WHERE s.turn_id=?",
            (turn_id,),
        ).fetchall()]
        return dict(turn_row), spans, predecessors

    def get_turn_graph(self, turn_id: str, projection: str) -> dict[str, Any]:
        if projection not in {"expanded", "aggregated"}:
            raise ValueError("unknown projection")
        with self._lock:
            cached = self._conn.execute(
                "SELECT projection_json FROM graph_projection_cache WHERE turn_id=? AND projection_type=?",
                (turn_id, projection),
            ).fetchone()
            if cached:
                return json.loads(cached[0])
            turn, spans, predecessors = self._graph_source(turn_id)
            graph = build_expanded(turn, spans, predecessors) if projection == "expanded" else build_aggregated(turn, spans, predecessors)
            self._conn.execute(
                "INSERT OR REPLACE INTO graph_projection_cache(turn_id,projection_type,source_revision,node_count,edge_count,projection_json,generated_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (turn_id, projection, len(spans), len(graph["nodes"]), len(graph["edges"]), _json(graph), _iso(datetime.now(timezone.utc))),
            )
            self._conn.commit()
            return graph

    def history_comparison(self, turn_id: str, session_ids: Iterable[str]) -> dict[str, Any]:
        with self._lock:
            current = self.get_turn_graph(turn_id, "aggregated")
            historical: list[dict[str, Any]] = []
            for session_id in session_ids:
                turn_rows = self._conn.execute("SELECT id FROM turns WHERE session_id=? ORDER BY sequence", (session_id,)).fetchall()
                historical.extend(self.get_turn_graph(row[0], "aggregated") for row in turn_rows)
            return merge_history(current, historical)

    def get_span(self, span_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT s.*,t.session_id FROM spans s JOIN turns t ON t.id=s.turn_id WHERE s.span_id=?", (span_id,),
            ).fetchone()
            if not row:
                return None
            result = dict(row)
            for key in ("attributes", "resource", "instrumentation_scope"):
                result[key] = json.loads(result[key] or "{}")
            result["input"] = self._get_payload(result.pop("input_payload_id"))
            result["output"] = self._get_payload(result.pop("output_payload_id"))
            result["predecessors"] = [dict(item) for item in self._conn.execute(
                "SELECT * FROM span_predecessors WHERE span_id=?", (span_id,),
            ).fetchall()]
            result["links"] = []
            result["log_count"] = self._conn.execute("SELECT COUNT(*) FROM log_records WHERE span_id=?", (span_id,)).fetchone()[0]
            return result

    def list_logs(self, span_id: str, *, limit: int = 100, cursor: str | None = None, level: str | None = None,
                  query: str | None = None) -> dict[str, Any]:
        clauses = ["span_id=?"]
        params: list[Any] = [span_id]
        if cursor:
            timestamp, log_id = cursor.split("|", 1)
            clauses.append("(timestamp>? OR (timestamp=? AND id>?))")
            params.extend([timestamp, timestamp, log_id])
        if level:
            clauses.append("level=?")
            params.append(level.upper())
        if query:
            clauses.append("(message LIKE ? OR fields LIKE ? OR exception LIKE ?)")
            params.extend([f"%{query}%"] * 3)
        params.append(min(max(limit, 1), 500) + 1)
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM log_records WHERE " + " AND ".join(clauses) + " ORDER BY timestamp,id LIMIT ?", params,
            ).fetchall()
        has_more = len(rows) > limit
        items = []
        for row in rows[:limit]:
            item = dict(row)
            item["fields"] = json.loads(item["fields"] or "{}")
            items.append(item)
        next_cursor = f"{items[-1]['timestamp']}|{items[-1]['id']}" if has_more and items else None
        return {"items": items, "next_cursor": next_cursor}

    def search(self, *, project_id: str, query: str, limit: int = 50, cursor: int | None = None, **_: Any) -> dict[str, Any]:
        offset = max(cursor or 0, 0)
        with self._lock:
            rows: list[sqlite3.Row] = []
            if self.fts_tokenizer and (self.fts_tokenizer != "trigram" or len(query) >= 3):
                match = '"' + query.replace('"', '""') + '"'
                try:
                    rows = self._conn.execute(
                        "SELECT rowid,project_id,session_id,turn_id,span_id,hit_type,"
                        "snippet(search_index,5,'[',']','...',24) snippet,timestamp FROM search_index "
                        "WHERE search_index MATCH ? AND project_id=? ORDER BY timestamp DESC,rowid DESC LIMIT ? OFFSET ?",
                        (match, project_id, min(max(limit, 1), 200) + 1, offset),
                    ).fetchall()
                except sqlite3.OperationalError:
                    rows = []
            if not rows:
                rows = self._conn.execute(
                    "SELECT id rowid,project_id,session_id,turn_id,span_id,hit_type,"
                    "CASE WHEN LENGTH(content)>180 THEN SUBSTR(content,1,180)||'...' ELSE content END snippet,timestamp "
                    "FROM search_documents WHERE project_id=? AND content LIKE ? "
                    "ORDER BY timestamp DESC,id DESC LIMIT ? OFFSET ?",
                    (project_id, f"%{query}%", min(max(limit, 1), 200) + 1, offset),
                ).fetchall()
            items = [dict(row) for row in rows[:limit]]
            for item in items:
                span = self._conn.execute("SELECT name,kind,status FROM spans WHERE span_id=?", (item["span_id"],)).fetchone()
                item.update(dict(span) if span else {"name": "", "kind": "", "status": ""})
        return {"items": items, "next_cursor": offset + limit if len(rows) > limit else None, "fts_tokenizer": self.fts_tokenizer}

    def storage_status(self) -> dict[str, Any]:
        with self._lock:
            counts = {
                "projects": self._conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0],
                "sessions": self._conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0],
                "turns": self._conn.execute("SELECT COUNT(*) FROM turns").fetchone()[0],
                "spans": self._conn.execute("SELECT COUNT(*) FROM spans").fetchone()[0],
                "logs": self._conn.execute("SELECT COUNT(*) FROM log_records").fetchone()[0],
            }
            bounds = self._conn.execute("SELECT MIN(started_at),MAX(ended_at) FROM sessions").fetchone()
            cleanup = self._conn.execute("SELECT value,updated_at FROM storage_events WHERE key='last_cleanup'").fetchone()
        size = sum(path.stat().st_size for path in self.path.parent.glob(self.path.name + "*"))
        return {
            "type": "sqlite", "path": str(self.path), "size_bytes": size, "counts": counts,
            "oldest_at": bounds[0], "newest_at": bounds[1], "fts_tokenizer": self.fts_tokenizer,
            "last_cleanup": json.loads(cleanup[0]) if cleanup else None,
        }

    def cleanup(self, *, max_age_days: int, max_storage: int, keep_pinned: bool = True,
                cleanup_target_ratio: float = 0.8) -> dict[str, Any]:
        cutoff = _iso(datetime.now(timezone.utc) - timedelta(days=max_age_days))
        deleted: list[str] = []
        with self._lock:
            old = self._conn.execute(
                "SELECT id FROM sessions WHERE started_at<?" + (" AND pinned=0" if keep_pinned else "") + " ORDER BY started_at",
                (cutoff,),
            ).fetchall()
            for row in old:
                if self.delete_session(row[0]):
                    deleted.append(row[0])
            self._conn.execute("PRAGMA wal_checkpoint(PASSIVE)")
            if self.storage_status()["size_bytes"] > max_storage:
                target = int(max_storage * cleanup_target_ratio)
                while self._logical_size() > target:
                    row = self._conn.execute(
                        "SELECT id FROM sessions" + (" WHERE pinned=0" if keep_pinned else "") + " ORDER BY started_at LIMIT 1"
                    ).fetchone()
                    if not row:
                        break
                    if self.delete_session(row[0]):
                        deleted.append(row[0])
            event = {"deleted_count": len(deleted), "deleted_session_ids": deleted, "ran_at": _iso(datetime.now(timezone.utc))}
            self._conn.execute("INSERT OR REPLACE INTO storage_events(key,value,updated_at) VALUES ('last_cleanup',?,?)", (_json(event), event["ran_at"]))
            self._delete_orphan_payloads()
            self._conn.commit()
            if deleted:
                self._conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                self._conn.execute("VACUUM")
            return event

    def clear_all(self) -> dict[str, int]:
        with self._lock:
            counts = {"sessions": self._conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]}
            if self.fts_tokenizer:
                self._conn.execute("DELETE FROM search_index")
            self._conn.execute("DELETE FROM sessions")
            self._conn.execute("DELETE FROM projects")
            self._delete_orphan_payloads()
            self._conn.commit()
            return counts

    def _delete_orphan_payloads(self) -> None:
        self._conn.execute(
            "DELETE FROM payloads WHERE id NOT IN (SELECT input_payload_id FROM turns WHERE input_payload_id IS NOT NULL "
            "UNION SELECT output_payload_id FROM turns WHERE output_payload_id IS NOT NULL "
            "UNION SELECT input_payload_id FROM spans WHERE input_payload_id IS NOT NULL "
            "UNION SELECT output_payload_id FROM spans WHERE output_payload_id IS NOT NULL)"
        )
