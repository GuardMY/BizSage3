from __future__ import annotations

from typing import Any


class NoOpStorage:
    """Fail-open sink used only when the configured writer cannot initialize."""

    capabilities: set[str] = set()

    def ensure_project(self, service_name: str) -> str:
        return "unavailable"

    def begin_turn(self, **_: Any) -> int:
        return 1

    def start_span(self, record: Any) -> None:
        return None

    def add_predecessor(self, *args: Any, **kwargs: Any) -> None:
        return None

    def end_span(self, record: Any) -> None:
        return None

    def finish_turn(self, **_: Any) -> None:
        return None

    def write_log(self, record: Any, event_key: str | None = None) -> None:
        return None

    def flush(self, timeout: float | None = None) -> None:
        return None

    def close(self) -> None:
        return None

    def cleanup(self, **_: Any) -> dict[str, Any]:
        return {"deleted_count": 0, "degraded": True}

    def storage_status(self) -> dict[str, Any]:
        return {"type": "unavailable", "size_bytes": 0, "counts": {}, "degraded": True}

