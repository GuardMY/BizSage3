from __future__ import annotations

from pydantic import BaseModel, Field


class PinRequest(BaseModel):
    pinned: bool


class HistoryComparisonRequest(BaseModel):
    session_ids: list[str] = Field(default_factory=list, max_length=20)


class CleanupRequest(BaseModel):
    max_age_days: int | None = Field(default=None, ge=1, le=3650)
    max_storage: int | None = Field(default=None, ge=1024 * 1024)

