from __future__ import annotations

import mimetypes
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from agenttrace.config import Config, load_config
from agenttrace.storage.sqlite import SQLiteStorage
from .schemas import CleanupRequest, HistoryComparisonRequest, PinRequest


def _error(code: str, message: str, request_id: str, detail: Any = None, status: int = 400) -> JSONResponse:
    return JSONResponse(status_code=status, content={"code": code, "message": message, "detail": detail or {}, "request_id": request_id})


def create_app(*, storage: SQLiteStorage | None = None, config: Config | None = None) -> FastAPI:
    cfg = config or load_config()
    backend = storage or SQLiteStorage(cfg.sqlite_path)
    owns_storage = storage is None

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        backend.cleanup(
            max_age_days=cfg.retention.max_age_days, max_storage=cfg.retention.max_storage,
            keep_pinned=cfg.retention.keep_pinned, cleanup_target_ratio=cfg.retention.cleanup_target_ratio,
        )
        yield
        if owns_storage:
            backend.close()

    app = FastAPI(title="AgentTrace", version="0.1.0", docs_url=None, redoc_url=None, lifespan=lifespan)
    app.state.storage = backend
    app.state.config = cfg

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        request_id = request.headers.get("x-request-id") or str(uuid4())
        request.state.request_id = request_id
        try:
            response = await call_next(request)
        except HTTPException as exc:
            return _error("NOT_FOUND" if exc.status_code == 404 else "REQUEST_FAILED", str(exc.detail), request_id, status=exc.status_code)
        except Exception:
            return _error("STORAGE_UNAVAILABLE", "无法读取当前日志存储", request_id, status=500)
        response.headers["x-request-id"] = request_id
        response.headers["x-content-type-options"] = "nosniff"
        response.headers["referrer-policy"] = "no-referrer"
        response.headers["content-security-policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'"
        return response

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        return _error("INVALID_REQUEST", "请求参数无效", request.state.request_id, exc.errors(), 422)

    @app.exception_handler(HTTPException)
    async def http_error(request: Request, exc: HTTPException):
        code = "NOT_FOUND" if exc.status_code == 404 else "REQUEST_FAILED"
        return _error(code, str(exc.detail), request.state.request_id, status=exc.status_code)

    @app.get("/api/projects")
    def projects():
        return {"items": backend.list_projects()}

    @app.get("/api/projects/{project_id}/sessions")
    def sessions(project_id: str, limit: int = Query(50, ge=1, le=200), cursor: str | None = None,
                 status: str | None = None, contains_error: bool | None = None, pinned: bool | None = None,
                 kind: str | None = None, query: str | None = None):
        return backend.list_sessions(project_id=project_id, limit=limit, cursor=cursor, status=status,
                                     contains_error=contains_error, pinned=pinned, kind=kind, query=query)

    @app.get("/api/sessions/{session_id}")
    def session(session_id: str):
        result = backend.get_session(session_id)
        if not result:
            raise HTTPException(404, "会话不存在")
        return result

    @app.patch("/api/sessions/{session_id}/pin")
    def pin_session(session_id: str, body: PinRequest):
        if not backend.set_pinned(session_id, body.pinned):
            raise HTTPException(404, "会话不存在")
        return {"id": session_id, "pinned": body.pinned}

    @app.delete("/api/sessions/{session_id}")
    def delete_session(session_id: str):
        if not backend.delete_session(session_id):
            raise HTTPException(404, "会话不存在")
        return {"deleted": True, "id": session_id}

    @app.get("/api/sessions/{session_id}/turns")
    def turns(session_id: str):
        if not backend.get_session(session_id):
            raise HTTPException(404, "会话不存在")
        return {"items": backend.list_turns(session_id)}

    @app.get("/api/sessions/{session_id}/aggregated")
    def session_aggregated(session_id: str):
        try:
            return backend.get_session_aggregated_graph(session_id)
        except KeyError:
            raise HTTPException(404, "会话不存在") from None

    @app.get("/api/turns/{turn_id}/expanded")
    def expanded(turn_id: str):
        try:
            return backend.get_turn_graph(turn_id, "expanded")
        except KeyError:
            raise HTTPException(404, "轮次不存在") from None

    @app.get("/api/turns/{turn_id}/aggregated")
    def aggregated(turn_id: str):
        try:
            return backend.get_turn_graph(turn_id, "aggregated")
        except KeyError:
            raise HTTPException(404, "轮次不存在") from None

    @app.post("/api/turns/{turn_id}/history-comparison")
    def history_comparison(turn_id: str, body: HistoryComparisonRequest):
        try:
            return backend.history_comparison(turn_id, body.session_ids)
        except KeyError:
            raise HTTPException(404, "轮次不存在") from None

    @app.get("/api/spans/{span_id}")
    def span(span_id: str):
        result = backend.get_span(span_id)
        if not result:
            raise HTTPException(404, "节点不存在")
        return result

    @app.get("/api/spans/{span_id}/logs")
    def logs(span_id: str, limit: int = Query(100, ge=1, le=500), cursor: str | None = None,
             level: str | None = None, query: str | None = None):
        if not backend.get_span(span_id):
            raise HTTPException(404, "节点不存在")
        return backend.list_logs(span_id, limit=limit, cursor=cursor, level=level, query=query)

    @app.get("/api/search")
    def search(project_id: str, query: str = Query(min_length=1, max_length=500),
               limit: int = Query(50, ge=1, le=200), cursor: int | None = None):
        return backend.search(project_id=project_id, query=query, limit=limit, cursor=cursor)

    @app.get("/api/storage/status")
    def storage_status():
        status = backend.storage_status()
        status["retention"] = {
            "max_age_days": cfg.retention.max_age_days, "max_storage": cfg.retention.max_storage,
            "keep_pinned": cfg.retention.keep_pinned, "cleanup_target_ratio": cfg.retention.cleanup_target_ratio,
        }
        return status

    @app.post("/api/storage/cleanup")
    def cleanup(body: CleanupRequest | None = None):
        request = body or CleanupRequest()
        return backend.cleanup(
            max_age_days=request.max_age_days or cfg.retention.max_age_days,
            max_storage=request.max_storage or cfg.retention.max_storage,
            keep_pinned=cfg.retention.keep_pinned, cleanup_target_ratio=cfg.retention.cleanup_target_ratio,
        )

    @app.delete("/api/storage/all")
    def clear_all():
        return {"deleted": backend.clear_all()}

    static_dir = Path(__file__).resolve().parent.parent / "web" / "static"
    assets_dir = static_dir / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        candidate = (static_dir / path).resolve()
        if path and candidate.is_relative_to(static_dir.resolve()) and candidate.is_file():
            return FileResponse(candidate, media_type=mimetypes.guess_type(candidate)[0])
        index = static_dir / "index.html"
        if index.exists():
            return FileResponse(index)
        return JSONResponse({"message": "AgentTrace Web UI 尚未构建", "api": "/api/projects"}, status_code=503)

    return app
