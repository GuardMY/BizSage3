from __future__ import annotations

import importlib.metadata
import logging
from typing import Iterable

from .base import Integration
from .sdk_wrappers import AnthropicIntegration, OpenAIIntegration

logger = logging.getLogger("agenttrace.internal.integrations")
_active: dict[str, Integration] = {}


def available_integrations() -> dict[str, Integration]:
    integrations: dict[str, Integration] = {
        "openai": OpenAIIntegration(),
        "anthropic": AnthropicIntegration(),
    }
    for entry in importlib.metadata.entry_points(group="agenttrace.integrations"):
        try:
            integrations[entry.name] = entry.load()()
        except Exception as exc:
            logger.warning("Cannot load AgentTrace integration %s: %s", entry.name, exc)
    return integrations


def instrument(names: Iterable[str], *, strict: bool = False) -> None:
    integrations = available_integrations()
    for name in names:
        if name in _active:
            continue
        integration = integrations.get(name)
        if not integration:
            message = f"No AgentTrace integration is registered for '{name}'"
            if strict:
                raise RuntimeError(message)
            logger.warning(message)
            continue
        try:
            if integration.is_available():
                integration.instrument()
                _active[name] = integration
            else:
                logger.warning("AgentTrace integration '%s' is not installed", name)
        except Exception as exc:
            if strict:
                raise
            logger.warning("AgentTrace disabled incompatible integration '%s': %s", name, exc)


def uninstrument() -> None:
    for integration in list(_active.values()):
        integration.uninstrument()
    _active.clear()

