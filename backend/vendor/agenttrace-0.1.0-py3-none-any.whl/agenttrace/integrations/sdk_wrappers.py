from __future__ import annotations

import importlib.util
from typing import Any

from agenttrace.api import trace


class _MethodIntegration:
    name = ""
    package = ""
    supported_versions = ">=0"
    targets: tuple[tuple[str, str, str], ...] = ()

    def __init__(self):
        self._originals: list[tuple[type[Any], str, Any]] = []

    def is_available(self) -> bool:
        return importlib.util.find_spec(self.package) is not None

    def instrument(self) -> None:
        for module_name, class_name, method_name in self.targets:
            try:
                module = __import__(module_name, fromlist=[class_name])
                cls = getattr(module, class_name)
                original = getattr(cls, method_name)
            except (ImportError, AttributeError):
                continue
            if getattr(original, "__agenttrace_wrapped__", False):
                continue
            decorator = trace.llm(name=f"{self.name}.{method_name}", node_key=f"{self.name}:{module_name}:{method_name}",
                                  attributes={"gen_ai.provider.name": self.name}, capture_input=True, capture_output=True)
            wrapped = decorator(original)
            wrapped.__agenttrace_wrapped__ = True
            self._originals.append((cls, method_name, original))
            setattr(cls, method_name, wrapped)

    def uninstrument(self) -> None:
        for cls, method_name, original in reversed(self._originals):
            setattr(cls, method_name, original)
        self._originals.clear()


class OpenAIIntegration(_MethodIntegration):
    name = "openai"
    package = "openai"
    supported_versions = ">=1.0"
    targets = (
        ("openai.resources.chat.completions.completions", "Completions", "create"),
        ("openai.resources.chat.completions.completions", "AsyncCompletions", "create"),
        ("openai.resources.responses.responses", "Responses", "create"),
        ("openai.resources.responses.responses", "AsyncResponses", "create"),
    )


class AnthropicIntegration(_MethodIntegration):
    name = "anthropic"
    package = "anthropic"
    supported_versions = ">=0.30"
    targets = (
        ("anthropic.resources.messages.messages", "Messages", "create"),
        ("anthropic.resources.messages.messages", "AsyncMessages", "create"),
    )
