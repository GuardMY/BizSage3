from __future__ import annotations

from typing import Protocol


class Integration(Protocol):
    name: str
    supported_versions: str
    def is_available(self) -> bool: ...
    def instrument(self) -> None: ...
    def uninstrument(self) -> None: ...

