from __future__ import annotations

import asyncio
import functools
import inspect
from collections.abc import AsyncGenerator, Callable, Generator
from typing import Any

from .context import session_var
from .runtime.recorder import Lifecycle, Recorder, uuid7


def _merged_chunks(chunks: list[Any]) -> Any:
    if all(isinstance(chunk, str) for chunk in chunks):
        return "".join(chunks)
    return chunks


class GeneratorProxy:
    def __init__(self, factory: Callable[[], Generator[Any, Any, Any]], lifecycle_factory: Callable[[], Lifecycle], capture_output: bool):
        self._factory = factory
        self._lifecycle_factory = lifecycle_factory
        self._capture_output = capture_output
        self._generator: Generator[Any, Any, Any] | None = None
        self._lifecycle: Lifecycle | None = None
        self._chunks: list[Any] = []
        self._done = False

    def __iter__(self) -> "GeneratorProxy":
        return self

    def _start(self) -> tuple[Generator[Any, Any, Any], Lifecycle]:
        if self._lifecycle is None:
            self._lifecycle = self._lifecycle_factory()
            with self._lifecycle.activate():
                self._generator = self._factory()
        return self._generator, self._lifecycle  # type: ignore[return-value]

    def _step(self, operation: str, *args: Any) -> Any:
        generator, lifecycle = self._start()
        try:
            with lifecycle.activate():
                chunk = getattr(generator, operation)(*args)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._done = True
            lifecycle.finish(output=_merged_chunks(self._chunks), capture_output=self._capture_output,
                             attributes={"agenttrace.stream.chunk_count": len(self._chunks), "agenttrace.stream.complete": True})
            raise
        except BaseException as exc:
            self._done = True
            lifecycle.finish(status="cancelled" if isinstance(exc, (GeneratorExit, asyncio.CancelledError)) else "error",
                             output=_merged_chunks(self._chunks), capture_output=self._capture_output, error=exc,
                             attributes={"agenttrace.stream.chunk_count": len(self._chunks), "agenttrace.stream.complete": False})
            raise

    def __next__(self) -> Any:
        return self._step("__next__")

    def send(self, value: Any) -> Any:
        return self._step("send", value)

    def throw(self, *args: Any) -> Any:
        return self._step("throw", *args)

    def close(self) -> None:
        if self._done:
            return
        generator, lifecycle = self._start()
        try:
            with lifecycle.activate():
                generator.close()
        finally:
            self._done = True
            lifecycle.finish(status="incomplete", output=_merged_chunks(self._chunks), capture_output=self._capture_output,
                             attributes={"agenttrace.stream.chunk_count": len(self._chunks), "agenttrace.stream.complete": False,
                                         "agenttrace.stream.stop_reason": "caller_closed"})

    def __del__(self) -> None:  # pragma: no cover - interpreter timing is implementation-specific
        if not self._done:
            try:
                self.close()
            except Exception:
                pass


class AsyncGeneratorProxy:
    def __init__(self, factory: Callable[[], AsyncGenerator[Any, Any]], lifecycle_factory: Callable[[], Lifecycle], capture_output: bool):
        self._factory = factory
        self._lifecycle_factory = lifecycle_factory
        self._capture_output = capture_output
        self._generator: AsyncGenerator[Any, Any] | None = None
        self._lifecycle: Lifecycle | None = None
        self._chunks: list[Any] = []
        self._done = False

    def __aiter__(self) -> "AsyncGeneratorProxy":
        return self

    def _start(self) -> tuple[AsyncGenerator[Any, Any], Lifecycle]:
        if self._lifecycle is None:
            self._lifecycle = self._lifecycle_factory()
            with self._lifecycle.activate():
                self._generator = self._factory()
        return self._generator, self._lifecycle  # type: ignore[return-value]

    async def _step(self, operation: str, *args: Any) -> Any:
        generator, lifecycle = self._start()
        try:
            with lifecycle.activate():
                chunk = await getattr(generator, operation)(*args)
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            self._done = True
            lifecycle.finish(output=_merged_chunks(self._chunks), capture_output=self._capture_output,
                             attributes={"agenttrace.stream.chunk_count": len(self._chunks), "agenttrace.stream.complete": True})
            raise
        except BaseException as exc:
            self._done = True
            lifecycle.finish(status="cancelled" if isinstance(exc, (GeneratorExit, asyncio.CancelledError)) else "error",
                             output=_merged_chunks(self._chunks), capture_output=self._capture_output, error=exc,
                             attributes={"agenttrace.stream.chunk_count": len(self._chunks), "agenttrace.stream.complete": False})
            raise

    async def __anext__(self) -> Any:
        return await self._step("__anext__")

    async def asend(self, value: Any) -> Any:
        return await self._step("asend", value)

    async def athrow(self, *args: Any) -> Any:
        return await self._step("athrow", *args)

    async def aclose(self) -> None:
        if self._done:
            return
        generator, lifecycle = self._start()
        try:
            with lifecycle.activate():
                await generator.aclose()
        finally:
            self._done = True
            lifecycle.finish(status="incomplete", output=_merged_chunks(self._chunks), capture_output=self._capture_output,
                             attributes={"agenttrace.stream.chunk_count": len(self._chunks), "agenttrace.stream.complete": False,
                                         "agenttrace.stream.stop_reason": "caller_closed"})


def decorate(recorder_getter: Callable[[], Recorder], fn: Callable[..., Any], *, kind: str, name: str | None,
             node_key: str | None, capture_input: bool, capture_output: bool, attributes: dict[str, Any] | None,
             tags: list[str] | None, session_id: str | Callable[..., str] | None = None) -> Callable[..., Any]:
    display_name = name or fn.__name__
    logical_key = node_key or f"{fn.__module__}:{fn.__qualname__}"
    all_attributes = {**(attributes or {})}
    if tags:
        all_attributes["agenttrace.tags"] = tags

    def lifecycle(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Lifecycle:
        recorder = recorder_getter()
        if kind == "turn":
            active = session_var.get()
            resolved = session_id(*args, **kwargs) if callable(session_id) else session_id
            resolved = resolved or (active.id if active else uuid7())
            return recorder.start_turn(name=display_name, logical_node_key=logical_key, session_id=str(resolved),
                                       args=args, kwargs=kwargs, capture_input=capture_input, attributes=all_attributes)
        return recorder.start_span(kind=kind, name=display_name, logical_node_key=logical_key, args=args, kwargs=kwargs,
                                   capture_input=capture_input, attributes=all_attributes)  # type: ignore[arg-type]

    if inspect.isasyncgenfunction(fn):
        @functools.wraps(fn)
        def async_generator_wrapper(*args: Any, **kwargs: Any) -> AsyncGeneratorProxy:
            return AsyncGeneratorProxy(lambda: fn(*args, **kwargs), lambda: lifecycle(args, kwargs), capture_output)
        return async_generator_wrapper

    if inspect.isgeneratorfunction(fn):
        @functools.wraps(fn)
        def generator_wrapper(*args: Any, **kwargs: Any) -> GeneratorProxy:
            return GeneratorProxy(lambda: fn(*args, **kwargs), lambda: lifecycle(args, kwargs), capture_output)
        return generator_wrapper

    if inspect.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            active = lifecycle(args, kwargs)
            try:
                with active.activate():
                    result = await fn(*args, **kwargs)
            except BaseException as exc:
                active.finish(status="cancelled" if isinstance(exc, asyncio.CancelledError) else "error", error=exc,
                              capture_output=False)
                raise
            active.finish(output=result, capture_output=capture_output)
            return result
        return async_wrapper

    @functools.wraps(fn)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        active = lifecycle(args, kwargs)
        try:
            with active.activate():
                result = fn(*args, **kwargs)
        except BaseException as exc:
            active.finish(status="error", error=exc, capture_output=False)
            raise
        active.finish(output=result, capture_output=capture_output)
        return result
    return sync_wrapper

