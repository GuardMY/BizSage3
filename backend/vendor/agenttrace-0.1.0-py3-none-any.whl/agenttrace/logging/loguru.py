from __future__ import annotations

from typing import Any

from .stdlib import capture_log


def loguru_sink(message: Any) -> None:
    record = message.record
    exception = None
    if record.get("exception"):
        exception = str(record["exception"])
    capture_log(
        level=record["level"].name, logger_name=record.get("name") or "loguru",
        message=record.get("message", str(message)), fields=dict(record.get("extra") or {}),
        exception=exception, source="loguru", event_key=str(record.get("extra", {}).get("agenttrace_event_id"))
        if record.get("extra", {}).get("agenttrace_event_id") else None,
        timestamp=record.get("time"),
    )
