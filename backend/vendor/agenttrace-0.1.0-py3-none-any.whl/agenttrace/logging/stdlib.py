from __future__ import annotations

import logging
import traceback
from datetime import datetime, timezone
from typing import Any

from agenttrace.context import current_context
from agenttrace.models import LogRecordData
from agenttrace.runtime.recorder import uuid7

_STANDARD_KEYS = set(logging.makeLogRecord({}).__dict__) | {"message", "asctime"}


def capture_log(*, level: str, logger_name: str, message: str, fields: dict[str, Any] | None,
                exception: str | None, source: str, event_key: str | None = None,
                timestamp: datetime | None = None) -> None:
    context = current_context()
    if not context:
        return
    from agenttrace.api import trace
    redactor = trace.recorder.redactor
    clean_message, _ = redactor.redact_text(str(message))
    clean_exception, _ = redactor.redact_text(exception) if exception else (None, 0)
    clean_fields = {}
    if fields:
        captured = redactor.redact_value(trace.recorder.capture(fields))
        try:
            import json
            clean_fields = json.loads(captured.content)
        except (TypeError, ValueError):
            clean_fields = {"value": captured.content}
    trace.storage.write_log(LogRecordData(
        id=uuid7(), timestamp=timestamp or datetime.now(timezone.utc), level=level.upper(),
        logger_name=logger_name, message=clean_message, fields=clean_fields,
        exception=clean_exception, source=source, **context,
    ), event_key=event_key)


class AgentTraceHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        if record.name.startswith("agenttrace.internal"):
            return
        try:
            fields = {key: value for key, value in record.__dict__.items() if key not in _STANDARD_KEYS and not key.startswith("agenttrace_")}
            exception = "".join(traceback.format_exception(*record.exc_info)) if record.exc_info else None
            event_key = getattr(record, "agenttrace_event_id", None) or f"logging:{id(record)}"
            capture_log(
                level=record.levelname, logger_name=record.name, message=record.getMessage(), fields=fields,
                exception=exception, source="logging", event_key=event_key,
                timestamp=datetime.fromtimestamp(record.created, timezone.utc),
            )
        except Exception:
            self.handleError(record)


_handler: AgentTraceHandler | None = None


def install_logging_handler(level: str = "INFO") -> AgentTraceHandler:
    global _handler
    if _handler is None:
        _handler = AgentTraceHandler(level=getattr(logging, level.upper(), logging.INFO))
        logging.getLogger().addHandler(_handler)
    else:
        _handler.setLevel(getattr(logging, level.upper(), logging.INFO))
    return _handler

