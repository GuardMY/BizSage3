from __future__ import annotations

from typing import Any

from .stdlib import capture_log


def structlog_processor(logger: Any, method_name: str, event_dict: dict[str, Any]) -> dict[str, Any]:
    event_key = event_dict.get("agenttrace_event_id")
    capture_log(
        level=str(event_dict.get("level", method_name)).upper(),
        logger_name=getattr(logger, "name", "structlog"),
        message=str(event_dict.get("event", "")),
        fields={key: value for key, value in event_dict.items() if key not in {"event", "level", "exception"}},
        exception=str(event_dict["exception"]) if event_dict.get("exception") else None,
        source="structlog", event_key=str(event_key) if event_key else None,
    )
    return event_dict
